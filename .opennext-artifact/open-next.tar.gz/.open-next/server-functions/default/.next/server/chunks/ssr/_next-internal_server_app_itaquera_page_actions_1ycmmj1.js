module.exports=[8817,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_itaquera_page_actions_1ycmmj1.js.map
globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/BDH7KU01jc7eIrmvBx3Ru/_buildManifest.js",
    "static/BDH7KU01jc7eIrmvBx3Ru/_ssgManifest.js",
    "static/BDH7KU01jc7eIrmvBx3Ru/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3hbdlqs046wry.js",
    "static/chunks/3-k2b6vno1p5k.js",
    "static/chunks/0q5ttdbfluzx2.js",
    "static/chunks/0ga5fcmdqvvn8.js",
    "static/chunks/turbopack-1t0wl2kpq5x1t.js"
  ]
};

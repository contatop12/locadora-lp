var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0o2m-pe._.js")
R.c("server/chunks/ssr/17io_next_dist_esm_build_templates_app-page_0av49hd.js")
R.c("server/chunks/ssr/[root-of-the-server]__17mpl4g._.js")
R.c("server/chunks/ssr/[root-of-the-server]__07u7892._.js")
R.c("server/chunks/ssr/17io_next_dist_client_components_builtin_global-error_0uktby0.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0zi5s8-.js")
R.m(35844)
module.exports=R.m(35844).exports
